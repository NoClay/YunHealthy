#ifndef MLX90614_H
#define MLX90614_H

float ReadTemperatureMLX90614(void);

#endif
