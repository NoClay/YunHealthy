#ifndef READ24C16_H
#define READ24C16_H

void ReadBG(unsigned char *p);
void DealBG(unsigned char *p, unsigned char *out);

#endif
